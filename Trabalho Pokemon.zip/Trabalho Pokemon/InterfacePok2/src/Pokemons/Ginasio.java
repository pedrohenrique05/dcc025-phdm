package pokemons;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Arrays;

/**
 *
 * @author Juarez
 */
public class Ginasio implements Serializable {


private String nomeGinasio, mestreGinasio;
private ArrayList <Pokemon> arrayPokemons = new ArrayList();
    
    /**
     * construtor
     */
    public Ginasio(){
    
    }
    /**
    * Seta o nome do mestre do ginasio
    * @param mestreGinasio - nome do mestre do ginásio
    */
    public void setMestreGinasio(String mestreGinasio) {
        this.mestreGinasio = mestreGinasio;
    }
    /**
     *
     * @return nome do mestre do ginasio
     */
    public String getMestreGinasio() {
        return this.mestreGinasio;
    }
    /**
     * Seta o pokemom no Array de pokemons que tem no ginasio
     * @param pokemons  - objeto pokemon já instânciado que está salvo na pokedex
     */
    public void setPokemons(Pokemon pokemons) {
        this.arrayPokemons.add(pokemons);
    }
    /**
     * 
     * @return retorna array de pokemons do ginasio
     */
    public ArrayList getPokemons() {
        return this.arrayPokemons;
    }
    /**
     * Setando o nome do ginasio
     * @param nomeGinasio - nome do ginasio
     */
    public void setNomeGinasio(String nomeGinasio) {
        this.nomeGinasio = nomeGinasio;
    }
    /**
     * 
     * @return o nome do ginasio
     */
    public String getNomeGinasio() {
        return this.nomeGinasio;
    }
}
