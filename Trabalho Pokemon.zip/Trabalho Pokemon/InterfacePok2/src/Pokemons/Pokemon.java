/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pokemons;

import java.io.Serializable;

/**
 *
 * @author Juarez
 */
public class Pokemon implements Serializable {
    private String nome, sexo, habilidade, descricao;
    private int altura, peso, numIdEvolucao = -1, evolucao = 0;
    /**
     * Construtor da classe.
     */
    public Pokemon() {
    }
    /**
     * 
     * @return O nome do pokemon
     */
    public String getNome() {
        return this.nome;
    }
    /**
     * seta o nome do pokemon
     * @param nome - nome do pokemon
     */
    public void setNome(String nome) {
        this.nome = nome;
    }
    /**
     * 
     * @return O sexo do pokemon
     */
    public String getSexo() {
        return this.sexo;
    }
    /**
     * Seta o sexo do pokemon
     * @param sexo - sexo do pokemon
     */
    public void setSexo(String sexo) {
        this.sexo = sexo;
    }
    /**
     * 
     * @return A habilidade do pokemon
     */
    public String getHabilidade() {
        return this.habilidade;
    }
    /**
     * Seta a habilidade do pokemon
     * @param habilidade - habilidade do pokemon
     */
    public void setHabilidade(String habilidade) {
        this.habilidade = habilidade;
    }
    /**
     * 
     * @return A descrição do pokemon
     */
    public String getDescricao() {
        return this.descricao;
    }
    /**
     * Seta a descrição do pokemon
     * @param descricao - descrição do pokemon
     */
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    /**
     * 
     * @return A altura do pokemon
     */
    public int getAltura() {
        return this.altura;
    }
    /**
     * Seta a altura do pokemon
     * @param altura - altura que o pokemon possui em centimetro
     */
    public void setAltura(int altura) {
        this.altura = altura;
    }
    /**
     * 
     * @return O peso do pokemon
     */
    public int getPeso() {
        return this.peso;
    }
    /**
     * Seta o peso do pokemon
     * @param peso - peso que o pokemon possui em quilograma.
     */
    public void setPeso(int peso) {
        this.peso = peso;
    }
    /**
     * 
     * @return O id do pokemon que o originou.
     */
    public int getNumIdEvolucao() {
        return this.numIdEvolucao;
    }
    /**
     * Setando o id do pokemon que o originou.
     * @param numIdEvolucao - id do pokemon "pai"
     */
    public void setNumIdEvolucao(int numIdEvolucao) {
        /**
         * Instância Pokedex para verificar se o id passado está dentro da faixa
         * existente de pokemons registrados na pokedex.
        */
        Pokedex pokAux = new Pokedex();
        if(numIdEvolucao > pokAux.getNumPokemon() || numIdEvolucao < 0){
                System.out.println("Id não válido!");
            }else{
                System.out.println("Numero de pokemons: "+pokAux.getNumPokemon());
                this.numIdEvolucao = numIdEvolucao;
               
            }
    }
    /**
     * 
     * @return Se o pokemon que está sendo setado é uma evolução ou não.
     */
    public int getEvolucao() {
        return this.evolucao;
    }
    /**
     * Seta um valor para assinalar se o pokemon que está sendo setado é uma evolução ou não
     * @param evolucao - valor em '0' para não ser evolução e '1' (ou qualquer número) para
     * ser evolução.
     */
    public void setEvolucao(int evolucao) {
        this.evolucao = evolucao;
    }
    
}
